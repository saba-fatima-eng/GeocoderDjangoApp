from django.shortcuts import render

import googlemaps
from geopy.geocoders import Nominatim
from django.shortcuts import render
from .forms import UserAddressForm
from .models import UserAddress


# geocoding 
def get_coordinates(address):
    # Use googlemaps or Nominatim geocoder (geopy) to get latitude and longitude
    gmaps = googlemaps.Client(key='YOUR_GOOGLE_MAP_API_KEY')
    geolocator = Nominatim(user_agent='geocoder_app')
    location = geolocator.geocode(address)

    if location:
        return location.latitude, location.longitude
    else:
        return None, None

def user_address_view(request):
    if request.method == 'POST':
        form = UserAddressForm(request.POST)
        if form.is_valid():
            address = f"{form.cleaned_data['house_number']} {form.cleaned_data['street']}, {form.cleaned_data['city']}, {form.cleaned_data['country']}"
            latitude, longitude = get_coordinates(address)
            form.instance.latitude = latitude
            form.instance.longitude = longitude
            form.save()
    else:
        form = UserAddressForm()

    return render(request, 'geocoder_app/user_address.html', {'form': form})

