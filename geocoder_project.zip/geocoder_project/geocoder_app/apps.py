from django.apps import AppConfig


class GeocoderAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'geocoder_app'
