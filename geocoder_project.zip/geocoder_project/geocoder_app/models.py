from django.db import models

class UserAddress(models.Model):
    zipcode = models.CharField(max_length=10)
    house_number = models.CharField(max_length=10)
    street = models.CharField(max_length=100)
    city = models.CharField(max_length=100)
    country = models.CharField(max_length=100)
    latitude = models.DecimalField(max_digits=20, decimal_places=6, null=True, blank=True)
    longitude = models.DecimalField(max_digits=20, decimal_places=6, null=True, blank=True)
